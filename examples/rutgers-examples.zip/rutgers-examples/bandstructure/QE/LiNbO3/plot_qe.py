#!/usr/bin/env python

import pyprocar

pyprocar.bandsplot(code="qe", mode="parametric", elimit=[-5, 5], orbitals=[1, 2, 3])
