#!/usr/bin/env python

import pyprocar

# Concatenate multiple PROCAR files due to parallelization in abinit
infiles = ["PROCAR_0000", "PROCAR_0001"]

pyprocar.cat(inFiles=infiles, outFile="PROCAR", mergeparallel=True)

# plotting bands with concatenated PROCAR file

pyprocar.bandsplot(
    "PROCAR",
    code="abinit",
    abinit_output="abinit.out",
    elimit=[-10, 10],
    mode="parametric",
    orbitals=[4, 5, 6, 7, 8],
)
