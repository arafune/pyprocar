#!/usr/bin/env python

import pyprocar

# elk plot exported as matplotlib object
fig, ax = pyprocar.bandsplot(
    code="elk", mode="plain", elimit=[-4, 4], show=False, color="k"
)

# vasp plot with previous axis ax
pyprocar.bandsplot(
    "PROCAR",
    code="vasp",
    mode="parametric",
    ax=ax,
    kpointsfile="KPOINTS",
    outcar="OUTCAR.sc",
    elimit=[-4, 4],
    orbitals=[4, 5, 6, 7, 8],
)
