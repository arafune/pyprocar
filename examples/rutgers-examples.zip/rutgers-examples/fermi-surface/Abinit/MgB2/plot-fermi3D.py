#!/usr/bin/env python

import pyprocar

# plain
pyprocar.fermi3D(
    "PROCAR",
    mode="plain",
    code="abinit",
    abinit_output="abinit.out",
    interpolation_factor=4,
)

# # orbital projection
# pyprocar.fermi3D(
#     "PROCAR",
#     mode="parametric",
#     code="vasp",
#     outcar="OUTCAR",
#     interpolation_factor=4,
#     orbitals=[3]
#     # fermi_shift=-0.5,
# )
