#!/usr/bin/env python

import pyprocar

# plain
pyprocar.fermi3D(
    "PROCAR",
    mode="plain",
    code="vasp",
    outcar="OUTCAR",
    interpolation_factor=4,
)

# orbital projection
pyprocar.fermi3D(
    "PROCAR",
    mode="parametric",
    code="vasp",
    outcar="OUTCAR",
    interpolation_factor=4,
    orbitals=[3]
    # fermi_shift=-0.5,
)

# show slice
pyprocar.fermi3D(
    "PROCAR",
    mode="plain",
    code="vasp",
    outcar="OUTCAR",
    interpolation_factor=4,
    show_slice=True,
    slice_normal=(1, 0, 0),
)
